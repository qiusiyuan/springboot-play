package com.qiusiyuan.SBAserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbAserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
